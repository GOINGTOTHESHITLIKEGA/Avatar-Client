Avatar-Client (Eaglecraft) - Placeholder README

This archive contains:
- client.jar (placeholder): replace with your actual client build before use.
- launcher.html: a local HTML launcher page with an Avatar-style background.
- background.png: decorative background used by launcher.html.

Compatibility: Minecraft 1.5.2 up to 1.12.2.

Instructions:
1) Replace client_files/client.jar with your real client .jar file.
2) Open launcher.html in your browser (double-click) and click "Download Client" to save the .jar.
3) Follow your server's install instructions. Hacks are not allowed.

Disclaimer: This package is a demo/template. It does not contain a working Minecraft client. Use at your own risk.
